import React, { useState } from "react"
import axios from "axios"

function App() {

  const [posts, setPosts] = useState([])

  const handleClick = () => {
    axios.get('http://localhost:3001/posts')
      .then(response => {
        setPosts(response.data);
      })
      .catch(error => {
        console.error(error);
      });
  }

  return (
    <>
    <div>
      <button onClick={handleClick}>Загрузить</button>
      <ul>
        {
          posts.map((post) => <li key={post.id}>{post.title}</li>)
        }
      </ul>
    </div>
    </>
  )
}

export default App
